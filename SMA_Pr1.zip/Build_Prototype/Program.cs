﻿///////////////////////////////////////////////////////////////////////////////////
// Program.cs - Prototype for build server.                                      //
//                                                                               //
// Avi Singhal, 947393120, CSE681, Fall'17, Software Modelling and Analysis      //
/////////////////////////////////////////////////////////////////////////////////// 
/*
 The following prototype is to show how to build C# files through solutions.

    Description : The prototype for the build server ( Project #1's requirement).
    Functionality : Builds the Solution - Program_1.sln
 */

using System;
using System.IO;
using System.Security;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Build.Construction;
using Microsoft.Build.Evaluation;
using Microsoft.Build.Execution;
using Microsoft.Build.Logging;
using Microsoft.Build.Framework;
using Microsoft.Build.Exceptions;
using Microsoft.Build.Utilities;

namespace Prototype
{
    class Prototype_pr1demo
    {
        static void Main(string[] args)
        {
            // The Build log should be shown on the console. We execute the current solution and what we expect is that the 
            // program_1.sln shoould be built.
            ProjectCollection pc = new ProjectCollection();
            Dictionary<string, string> globalProperty = new Dictionary<string, string>();
            BuildParameters bp = new BuildParameters(pc);

            ConsoleLogger logger = new ConsoleLogger(LoggerVerbosity.Detailed);
            bp.Loggers = new List<ILogger> { logger };                                        
            bp.DetailedSummary = true;

            BuildRequestData buildRequest = new BuildRequestData("../../../Program_1.sln", globalProperty, "4.0", new string[] { "Build" }, null); //--passing the solution--
            BuildResult buildResult = BuildManager.DefaultBuildManager.Build(bp, buildRequest);
            Console.ReadLine();
        }
    }
}
